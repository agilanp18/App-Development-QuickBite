import React, { useState } from 'react';
import './Checkout.css';
import { Link } from 'react-router-dom';
import { useGlobelContext } from '../Context/ProductContext';

function Checkout() {
  const{total}=useGlobelContext()
  const [formData, setFormData] = useState({
    name: '',
    platformNo: '',
    trainNo: '',
    seatNo:''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // You can add form submission logic here, such as processing payment or sending data to a server
    console.log('Form submitted:', formData);
    // Clear the form after submission
    setFormData({
      name: '',
      address: '',
      totalPayment: '',
    });
  };

  return (
    <div className="checkout-container">
      <h2>Checkout</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="address">Platform Number</label>
          <input
            type="text"
            id="platformNo"
            name="platformNo"
            value={formData.platformNo}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="totalPayment">Train Number</label>
          <input
            type="number"
            id="trainNo"
            name="trainNo"
            value={formData.trainNo}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="totalPayment">Seat Number</label>
          <input
            type="number"
            id="seatNo"
            name="seatNo"
            value={formData.seatNo}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <p>{total}</p>
        </div>
        <button type="submit" className="checkout-button"><Link to='/CartForm'>Pay Now</Link></button>
      </form>
    </div>
  );
}

export default Checkout;
